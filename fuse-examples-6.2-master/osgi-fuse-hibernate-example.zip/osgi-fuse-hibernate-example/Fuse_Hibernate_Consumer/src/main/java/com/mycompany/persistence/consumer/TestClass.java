package com.mycompany.persistence.consumer;

public class TestClass {

}
