package com.mycompany.spring.datasource;

/**
 * An interface for implementing Hello services.
 */
public interface Hello {

    String hello();
	
}
